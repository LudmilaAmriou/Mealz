package com.example.mealz

const val url = "https://6e62-41-108-139-109.ngrok-free.app"
