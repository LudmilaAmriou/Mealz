package com.example.mealz.Entity

data class Commande_menu(
    val ID_Commande: Int?,
    val ID_Menu: Int?,
    val Size: Int?,
    val Quantite:Int?,
    val Notes:String?,
    val ID_Restaurant: Int?,
    )