package com.example.mealz.Adapter

import com.example.mealz.Entity.Restaurant


interface CellClickListener {
    fun onCellClickListener(data: Restaurant)
}