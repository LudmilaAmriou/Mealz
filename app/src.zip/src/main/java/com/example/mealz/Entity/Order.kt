package com.example.mealz.Entity

data class Order(
    val ID_Commande : Int,
    val Adresse_livraison : String?,
    val Prix_Tolal : Int?,
    val Nom: String?,
    val NomMs:String?,

)
