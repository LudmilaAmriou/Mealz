package com.example.mealz.Entity

data class LoginRequest(
    var mail: String,
    var password: String
)
