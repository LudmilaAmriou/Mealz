package com.example.mealz.Entity


data class utilisateur(
        val success:Boolean,
        val ID_Utilisateur:Int?,
        val message: String?,
)